/**
 * Copyright @ 2023 - 2025 iAUTO(Shanghai) Co., Ltd.
 * All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are NOT permitted except as agreed by
 * iAUTO(Shanghai) Co., Ltd.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
package com.iauto.electronicom.service.search;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.database.sqlite.SQLiteDatabase;

import java.io.FileOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.iauto.eomapi.SearchResultItem;

/**
 * EOMSearch class
 */
public class EOMSearch {
    private static final String TAG = "EOM-SERVICE";
    private static final String CLASS_NAME = "EOMSearch ";
    private static final String TABLE_NAME = "eomsearch";
    private static final String DATABASE_KEY_CN       = "key_cn";
    private static final String DATABASE_KEY_EN       = "key_en";
    private static final String DATABASE_RETURN_KEY   = "funcid";

    private static final String EOM_SEARCH_DB = "EOMSearch.db";

    private static EOMSearch sInstance = null;
    private Context mContext = null;
    private SQLiteDatabase m_SQLiteDatabase;

    public static synchronized EOMSearch getInstance() {
        if (null == sInstance) {
            sInstance = new EOMSearch();
        }
        return sInstance;
    }

    public synchronized void initialize(Context context) {
        mContext = context;

        if (checkDataBaseFile()) {
            openDataBase();
        }
    }

    public void openDataBase() {
        Log.i(TAG, String.format("[DataBase] openDataBase"));
        String path = mContext.getDatabasePath(EOM_SEARCH_DB).getAbsolutePath();
        Log.i(TAG, "openDataBase path=" + path);
        m_SQLiteDatabase = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY);
    }

    public ArrayList<SearchResultItem> query(String word) {
        Log.i(TAG, CLASS_NAME + "query begin");
        ArrayList<SearchResultItem> valueList = new ArrayList<>();
        if (m_SQLiteDatabase == null) {
            Log.i(TAG, CLASS_NAME + "query sql lite data base is null");
            return null;
        }
        else if (!m_SQLiteDatabase.isOpen()) {
            Log.i(TAG, CLASS_NAME + "query sql lite data base is close");
            return null;
        }
        else if (word == null) {
            Log.i(TAG, CLASS_NAME + "query parameter error");
            return null;
        }
        else {
            final String language = getLanguageKey();

            final String sql = "select " + language + "," + DATABASE_RETURN_KEY + " from " + TABLE_NAME + " where " + language + " LIKE ?";
            Log.i(TAG, CLASS_NAME + "query sql=" + sql);
            String searchword = "%" + word.trim() + "%";
            Log.i(TAG, CLASS_NAME + "query searchword=" + searchword);
            String[] args = new String[] {searchword};
            final Cursor cursor = m_SQLiteDatabase.rawQuery(sql, args);
            Log.i(TAG, CLASS_NAME + "query rawQuery finish");

            if (cursor != null && cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    final String key = cursor.getString(cursor.getColumnIndex(language));
                    final String value = cursor.getString(cursor.getColumnIndex(DATABASE_RETURN_KEY));

                    Log.i(TAG, String.format("[DataBase] query() key[%s] value[%s]",
                            key, value));
                    SearchResultItem item = new SearchResultItem();
                    item.setName(key);
                    item.setId(value);
                    valueList.add(item);
                }
            }
            else {
                Log.i(TAG, CLASS_NAME + "query cursor is null");
            }
        }
        return valueList;
    }

    private String getLanguageKey() {
        String locale = Locale.getDefault().getLanguage();
        if (null == locale) {
            Log.i(TAG, CLASS_NAME + "getLanguageKey() locale is null");
            locale = DATABASE_KEY_CN;
        }
        else {
            Log.i(TAG, String.format("[DataBase] getLanguageKye() locale language is %s", locale));
            if (locale.equals("zh")) {
                locale = DATABASE_KEY_CN;
            }
            else {
                locale = DATABASE_KEY_EN;
            }
        }
        return locale;
    }

    private boolean checkDataBaseFile() {

        boolean ret = true;
        File file = mContext.getDatabasePath(EOM_SEARCH_DB);
        if (file.exists()) {
            Log.i(TAG, CLASS_NAME + " checkDataBaseFile() exists");
        }
        else {
            InputStream inputStream = null;
            FileOutputStream outFile = null;
            byte[] buffer = new byte[1024];
            try {
                Log.i(TAG, CLASS_NAME + " checkDataBaseFile() copy database");
                inputStream = mContext.getResources().getAssets().open(
                        EOM_SEARCH_DB);
                outFile = new FileOutputStream(file);
                int count;
                while ((count = inputStream.read(buffer)) > 0) {
                    outFile.write(buffer, 0, count);
                }
            } catch (Exception e) {
                ret = false;
                Log.i(TAG, CLASS_NAME + " initDataBase() Exception", e);
            } finally {
                try {
                    if (outFile != null) {
                        outFile.close();
                    }
                    if (inputStream != null) {
                        inputStream.close();
                    }
                }
                catch (Exception ee) {
                    ee.printStackTrace();
                }
            }
        }
        return ret;
    }
}
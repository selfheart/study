/**
 * Copyright @ 2023 - 2025 iAUTO(Shanghai) Co., Ltd.
 * All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are NOT permitted except as agreed by
 * iAUTO(Shanghai) Co., Ltd.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
package com.iauto.electronicom.service.search;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import com.iauto.globalsearch.GlobalSearchDefine;
import com.iauto.electronicom.service.EOMServiceImpl;
import com.iauto.eomapi.SearchResultItem;

/**
 * EOMSearchProvider class
 */
public class EOMSearchProvider extends ContentProvider {
    private static final String TAG = "EOM-SERVICE";
    private static final String CLASS_NAME = "EOMSearchProvider::";

    @Override
    public boolean onCreate() {
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection,
                        @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        return null;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs,
                        @Nullable String sortOrder, @Nullable CancellationSignal cancellationSignal) {
        return doQuery(uri, projection, selection, selectionArgs, sortOrder, cancellationSignal);
    }

    public @Nullable Cursor doQuery(@NonNull Uri uri,
                                    @Nullable String[] projection,
                                    @Nullable String selection,
                                    @Nullable String[] selectionArgs,
                                    @Nullable String sortOrder,
                                    @Nullable CancellationSignal cancellationSignal)
    {
        Log.i(TAG, CLASS_NAME + " doQuery()");
        final GlobalSearchDefine.QueryObj queryObj = GlobalSearchDefine.QueryObj.createInstance(uri,
                projection, selection, selectionArgs, sortOrder, cancellationSignal);


        final int searchType = queryObj.getSearchType();
        Log.i(TAG, String.format(CLASS_NAME + " doQuery() search type: %d", searchType));
        if (searchType == GlobalSearchDefine.SEARCH_TYPE_EOM) {
            Log.i(TAG, String.format(CLASS_NAME + " doQuery() authority: %s", queryObj.getAuthorityInfo()));
            queryObj.setOnCancelListener(
                    () -> Log.i(TAG, CLASS_NAME + " onCancel() cancel search"),
                    new Handler(Looper.myLooper()));

            new Thread(() -> {
                Log.i(TAG, String.format(CLASS_NAME + " doQuery() start screen[%s] limit[%d] words:%s",
                        (queryObj.isPScreen() ? "P" : "D"),
                        queryObj.getResultCountLimit(),
                        queryObj.getQueryString()));

                final int limit = queryObj.getResultCountLimit();
                final String[] searchWords = queryObj.getQueryWordsArray();
                Set<SearchResultItem> keySet = new HashSet<>();
                for (String words : searchWords) {
                    ArrayList<SearchResultItem> itemList = new ArrayList<>();
                    EOMServiceImpl instance = EOMServiceImpl.getInstance();
                    if (null != instance) {
                        itemList = instance.query(words);
                        keySet.addAll(itemList);
                    }
                    if (queryObj.isCancelled()) {
                        Log.i(TAG, CLASS_NAME + " doQuery() search is cancelled");
                        break;
                    }
                }

                if (queryObj.isCancelled()) {
                    Log.i(TAG, CLASS_NAME + " doQuery() search is cancelled");
                }
                else {
                    int position = 0;
                    for (SearchResultItem key : keySet) {
                        queryObj.setColumnDataByColumnNameInPosition(position,
                                GlobalSearchDefine.SUGGEST_COLUMN_INTENT_DATA, key.getId());
                        position++;
                        if (position >= limit) {
                            break;
                        }
                    }

                    Log.i(TAG, CLASS_NAME + " doQuery() search is not Cancelled");
                }

                queryObj.searchEndInSearchThread();
                Log.i(TAG, CLASS_NAME + " doQuery() search end");
            }).start();
        }
        else {
            Log.i(TAG, CLASS_NAME + " doQuery() unknown search type");
        }

        queryObj.waitInQueryThread();

        Log.i(TAG, CLASS_NAME + " doQuery() search end");
        return queryObj.getResult();
    }

    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }

    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }
}

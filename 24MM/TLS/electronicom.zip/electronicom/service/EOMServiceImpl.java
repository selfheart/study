package com.iauto.electronicom.service;

import android.content.Context;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import com.iauto.eomapi.IEOMListener;
import com.iauto.eomapi.IEOMManager;
import com.iauto.eomapi.EOMDataInfoDef;
import com.iauto.eomapi.TabCategoryItem;
import com.iauto.eomapi.FuncListItem;
import com.iauto.eomapi.SecondFuncListItem;
import com.iauto.eomapi.VideoItem;
import com.iauto.eomapi.SearchHistoryItem;
import com.iauto.eomapi.SearchResultItem;
import com.iauto.electronicom.service.search.EOMSearch;

import com.iauto.cardata.CarData;
import com.iauto.cardata.CarDataValue;
import com.iauto.cardata.ConnectCallback;
import com.iauto.message.CarNotification;
import com.iauto.message.MessageServiceManager;
import com.iauto.gbookapi.GBookServiceManager;
import com.iauto.gbookapi.GBookManager;
import com.iauto.gbookapi.IGBookDef;
import com.iauto.gbookapi.GBookListener;
import com.iauto.gbookapi.TSConnectHttpRequestIn;
import com.iauto.gbookapi.TSConnectHttpRequestOut;
import com.iauto.gbookapi.TSConnectHttpProgress;
import com.iauto.globalsearch.GlobalSearchDefine;

public class EOMServiceImpl extends IEOMManager.Stub {
    private static final String TAG = "EOM-SERVICE";
    private static final String CLASS_NAME = "EOMServiceImpl ";

    // private static String checkUrl = "https://auto24mm.g-book.com.cn/ClientAuth/24MM/Get3DModelAndOMUpdateFlag";
    // private static String downloadUrl = "https://auto24mmresourcedl.g-book.com.cn/CDN_OM/";
    // private static String DOWNLOAD_PATH = "/resdata/ElectronicOM/";
    private static String checkUrl = "https://test24mm.g-book.com.cn/ClientAuth/24MM/Get3DModelAndOMUpdateFlag";
    private static String downloadUrl = "https://test24mmresourcedl.g-book.com.cn/CDN_OM/";
    private static String DOWNLOAD_PATH = "/resdata/ElectronicOM/";

    private static final String CONFIG_FILE = "/resdata/ElectronicOM/config.json";
    private static String RESOURCE_VIDEO_PATH = "/resdata/ElectronicOM/%s/%s/%s";
    private static String RESOURCE_H5_PATH = "/resdata/ElectronicOM/%s/%s/%s";

    private static final Integer SEARCH_RESULT_MAX = 50;

    private static EOMServiceImpl sInstance = null;
    private Context mContext;
    private final Map<IBinder, EOMManagerDeathRecipient> mDeathRecipientMap = new ConcurrentHashMap<>();

    private final Map<IBinder, IEOMListener> mListenerMap = new ConcurrentHashMap<>();
    private ReentrantReadWriteLock mLockListener = new ReentrantReadWriteLock();  // Listener lock

    private GBookServiceManager mGBookServiceManager;
    private MyGBookServiceConnectionListener mGBookServiceConnectionListener;
    private MyGBookListener mGBookListener;
    private GBookManager mGBookManager;

    private CarData mCarData;
    private MyCarDataConnectCallback mCarDataConnectCallback;

    private EOMSearch mEOMSearch = null;

    private JSONObject mVersionJsonObject = new JSONObject();
    private ArrayList<EOMUpdateInfo> mDownloadList = new ArrayList<>();
    private Integer mReqId = 0;
    private Map<Integer, String> mUpdateMap = new HashMap<>();

    private ArrayList<TabCategoryItem> mTabList = new ArrayList<>();
    private ArrayList<VideoItem> mVideoList = new ArrayList<>();
    private Map<String, String> mSecondFuncUrlList = new HashMap<>();
    private Map<String, String> mSecondFuncTitleList = new HashMap<>();

    private int mUpdateState = EOMDataInfoDef.UPDATE_STATUS.NOUPDATE;

    public class EOMUpdateInfo {
        public String url;
        public String version;
        public String id;
        public String md5;
    }

    public synchronized static EOMServiceImpl getInstance(Context serviceContext) {
        if (null == sInstance) {
            sInstance = new EOMServiceImpl(serviceContext);
        }
        return sInstance;
    }

    public static EOMServiceImpl getInstance() {
        return sInstance;
    }

    public void releaseInstance() {
        if (null != sInstance) {
            sInstance = null;
        }
    }

    public void init() {
        Log.i(TAG, CLASS_NAME + "init begin");

        mCarDataConnectCallback = new MyCarDataConnectCallback();
        mCarData = new CarData(mContext, mCarDataConnectCallback);

        parseConfigJson();
        initSearch();

        mGBookServiceConnectionListener = new MyGBookServiceConnectionListener();
        mGBookServiceManager = GBookServiceManager.createGBookServiceManager(mContext, mGBookServiceConnectionListener);
        try {
            mGBookServiceManager.connect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.i(TAG, CLASS_NAME + "init end");
    }

    private EOMServiceImpl(Context serviceContext) {
        mContext = serviceContext;
    }

    public CarData getCarData() {
        if (mCarData == null) {
            mCarData = new CarData(mContext, mCarDataConnectCallback);
        }
        return mCarData;
    }

    private class EOMManagerDeathRecipient implements IBinder.DeathRecipient {
        private IBinder mListenerBinder;

        EOMManagerDeathRecipient(IBinder listenerBinder) {
            mListenerBinder = listenerBinder;
        }

        /**
         * Client died. Remove the listener from HAL service and unregister if this is the last
         * client.
         */
        @Override
        public void binderDied() {
            mListenerBinder.unlinkToDeath(this, 0);
            sInstance.unregisterListenerLocked(mListenerBinder);
        }
    }

    private void unregisterListenerLocked(IBinder listenerBinder) {
        mListenerMap.remove(listenerBinder);
        mDeathRecipientMap.remove(listenerBinder);
    }

    @Override
    public boolean registerListener(IEOMListener listener) throws RemoteException {
        if (null == listener) {
            Log.i(TAG, CLASS_NAME + "registerListener listener is null, return");
            return false;
        }

        IBinder listenerBinder = listener.asBinder();
        if (mListenerMap.containsKey(listenerBinder)) {
            // Already registered, nothing to do.
            return true;
        }

        EOMManagerDeathRecipient deathRecipient = new EOMManagerDeathRecipient(listenerBinder);
        listenerBinder.linkToDeath(deathRecipient, 0);
        mDeathRecipientMap.put(listenerBinder, deathRecipient);
        mListenerMap.put(listenerBinder, listener);
        return true;
    }

    @Override
    public boolean unregisterListener(IEOMListener listener) throws RemoteException {
        return true;
    }

    private void initSearch() {
        Log.i(TAG, CLASS_NAME + " initSearch() begin");

        // initialize EOMSearch
        mEOMSearch = EOMSearch.getInstance();
        mEOMSearch.initialize(mContext);

        Log.i(TAG, CLASS_NAME + " initSearch() end");
    }

    private void initGBookData() {
        Log.i(TAG, CLASS_NAME + "initGBookData begin");
        check3DAndOMUpdateFlag();
        boolean hasUpdate = false;
        // get if need check update from cardata
        if (!hasUpdate) {
            Log.i(TAG, CLASS_NAME + "initGBookData no update return");
            return;
        }
        Log.i(TAG, CLASS_NAME + "initGBookData end");
    }

    private void check3DAndOMUpdateFlag() {
        Log.i(TAG, CLASS_NAME + "check3DAndOMUpdateFlag begin");
        if (null != mGBookManager) {
            if (!mGBookManager.getHttpCommonHeaderReadyStatus()) {
                Log.i(TAG, CLASS_NAME + "check3DAndOMUpdateFlag getHttpCommonHeaderReadyStatus not ready");
                return;
            }

            TSConnectHttpRequestIn req = new TSConnectHttpRequestIn();

            req.setConnectId("com.iauto.electronicom");
            req.setReqId(mReqId);
            mReqId++;
            req.setReqType(IGBookDef.ReqType.TSCONNECT_REQ_TYPE_GBOOK);
            req.setReqMethod(IGBookDef.ReqMethod.TSCONNECT_REQ_METHOD_POST);
            req.setUrl(checkUrl);
            String requestId = java.util.UUID.randomUUID().toString();
            req.addHttpHeaders("requestId", requestId);
            req.addHttpHeaders("Content-Type", "application/json;charset=UTF-8");
            req.setPosDataType(IGBookDef.PosDataType.TSCONNECT_POSDATA_BUF);
            try {
                Log.i(TAG, CLASS_NAME + "check3DAndOMUpdateFlag mVersionJsonObject=" + mVersionJsonObject.toString());
                req.setPosData((mVersionJsonObject.toString()).getBytes("UTF-8"));  // json to byte
            } catch (Exception e) {
                e.printStackTrace();
            }
            req.setResDataType(IGBookDef.ResDataType.TSCONNECT_RESDATA_BUF);

            mGBookManager.requestSvrHttp(req);
        }
        else {
            Log.i(TAG, CLASS_NAME + "check3DAndOMUpdateFlag GBookManager is null");
        }
        Log.i(TAG, CLASS_NAME + "check3DAndOMUpdateFlag end");
    }

    private void setTablistUpdateStatus() {
        Log.i(TAG, CLASS_NAME + "setTablistUpdateStatus begin");
        for (int i = 0; i < mDownloadList.size(); i++) {
            String id = mDownloadList.get(i).id;
            boolean isSetUpdate = false;
            for (int j = 0; j < mTabList.size(); j++) {
                ArrayList<FuncListItem> funclist = mTabList.get(j).getFuncList();
                for (int k = 0; k < funclist.size(); k++) {
                    if (funclist.get(k).getId().equals(id)) {
                        mTabList.get(i).setUpdateState(EOMDataInfoDef.UPDATE_STATUS.WAITUPDATE);
                        isSetUpdate = true;
                        continue;
                    }
                }
                if (isSetUpdate) {
                    continue;
                }
            }
        }
        updateTablist();
        Log.i(TAG, CLASS_NAME + "setTablistUpdateStatus end");
    }

    private void updateTabDownloadStatus() {
        Log.i(TAG, CLASS_NAME + "updateTabDownloadStatus begin");
        for (int i = 0; i < mTabList.size(); i++) {
            ArrayList<FuncListItem> funclist = mTabList.get(i).getFuncList();
            boolean isSetUpdate = false;
            if (mDownloadList.size() > 0) {
                for (int j = 0; j < funclist.size(); j++) {
                    for (int k = 0; k < mDownloadList.size(); k++) {
                        String id = mDownloadList.get(k).id;
                        if (funclist.get(j).getId().equals(id)) {
                            isSetUpdate = true;
                            break;
                        }
                    }
                    if (isSetUpdate) {
                        break;
                    }
                }
            }
            if (!isSetUpdate) {
                Log.i(TAG, CLASS_NAME + "updateTabDownloadStatus tab=" + mTabList.get(i).getName());
                mTabList.get(i).setUpdateState(EOMDataInfoDef.UPDATE_STATUS.NOUPDATE);
                updateTablist();
            }
        }

        Log.i(TAG, CLASS_NAME + "updateTabDownloadStatus end");
    }

    private void updateTablist() {
        Log.i(TAG, CLASS_NAME + "updateTablist begin");
        mLockListener.readLock().lock();
        for (IEOMListener listener : mListenerMap.values()) {
            try {
                listener.onNotifyTabListChange(mTabList);
            } catch (Exception e) {
                Log.e(TAG, Log.getStackTraceString(e));
            }
        }
        mLockListener.readLock().unlock();
        Log.i(TAG, CLASS_NAME + "updateTablist end");
    }

    private void updateDownloadFinish(String finishId) {
        Log.i(TAG, CLASS_NAME + "updateDownloadFinish finishId=" + finishId);
        for (int i = 0; i < mDownloadList.size(); i++) {
            String id = mDownloadList.get(i).id;
            if (finishId.equals(id)) {
                mDownloadList.remove(i);
                break;
            }
        }
        if (mDownloadList.size() <= 0) {
            setUpdataState(EOMDataInfoDef.UPDATE_STATUS.NOUPDATE);
        }
        updateTabDownloadStatus();
    }

    // CarData Service Connect listener
    public class MyCarDataConnectCallback implements ConnectCallback {

        @Override
        public void onServiceConnected() {
            Log.d(TAG, CLASS_NAME + " MyCarDataConnectCallback onServiceConnected ");
        }

        @Override
        public void onServiceDisconnected() {
            Log.d(TAG, CLASS_NAME + " MyCarDataConnectCallback onServiceDisconnected ");
        }
    }

    public class MyGBookServiceConnectionListener implements GBookServiceManager.ServiceConnectionListener {
        @Override
        public void onServiceConnected()
        {
            Log.d(TAG, CLASS_NAME + "MyGBookServiceConnectionListener onServiceConnected");
            if (null != mGBookServiceManager) {
                mGBookManager = mGBookServiceManager.getGBookManager();
                if (null != mGBookManager) {
                    mGBookListener = new MyGBookListener();
                    mGBookManager.registerListener(mGBookListener);
                    initGBookData();
                }
            }
        }

        @Override
        public void onServiceDisconnected()
        {
            Log.d(TAG, CLASS_NAME + "MyGBookServiceConnectionListener onServiceDisconnected");
        }
    }

    public class MyGBookListener extends GBookListener {

        @Override
        public void onReplySvrHttp(TSConnectHttpRequestOut rep) {
            Log.d(TAG, CLASS_NAME + "MyGBookListener onReplySvrHttp id=" + rep.getConnectId());
            Log.d(TAG, CLASS_NAME + "MyGBookListener onReplySvrHttp code=" + rep.getResCode());
            Log.d(TAG, CLASS_NAME + "MyGBookListener onReplySvrHttp file=" + rep.getResFileName());
            if (null != rep) {
                if (rep.getConnectId().equals("com.iauto.electronicom")) {
                    try {

                        byte[] data = rep.getResData();
                        String str = new String(data, "UTF-8");
                        Log.d(TAG, CLASS_NAME + "MyGBookListener onReplySvrHttp str=[" + str + "]");
                        JSONObject repJSONObject = new JSONObject(str);

                        String update3DFlag = repJSONObject.getString("3DupdateFlag");
                        if (update3DFlag.equals("1")) {
                            // update cardata
                            CarData carData = getCarData();
                            try {
                                CarDataValue dataValue = new CarDataValue();
                                dataValue.setInt(1);
                                carData.setValue("DM_BK_3DCARMODEL_UPDATE_FLAG", dataValue);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                        String omUpdateFlag = repJSONObject.getString("omUpdateFlag");
                        Log.d(TAG, CLASS_NAME + "MyGBookListener onReplySvrHttp omUpdateFlag=" + omUpdateFlag);
                        if (null != omUpdateFlag && omUpdateFlag.equals("1")) {
                            JSONArray resourceList = repJSONObject.getJSONArray("omResourceList");
                            Log.d(TAG, CLASS_NAME + "onReplySvrHttp om resourcelist length=" + resourceList.length());
                            for (int i = 0; i < resourceList.length(); i++) {
                                JSONObject resourceObj = resourceList.getJSONObject(i);
                                String resourceID = resourceObj.getString("resourceID");
                                String resourceVersion = resourceObj.getString("resourceVersion");
                                String resourceUrl = resourceObj.getString("resourceUrl");
                                String md5 = resourceObj.getString("md5");
                                Log.d(TAG, CLASS_NAME + "    ---- resourceID=" + resourceID);
                                Log.d(TAG, CLASS_NAME + "    ---- resourceVersion=" + resourceVersion);
                                Log.d(TAG, CLASS_NAME + "    ---- resourceUrl=" + resourceUrl);

                                JSONArray list = mVersionJsonObject.getJSONArray("omResourceList");
                                Log.d(TAG, CLASS_NAME + "onReplySvrHttp om current resourcelist length=" + list.length());
                                for (int j = 0; j < list.length(); j++) {
                                    JSONObject obj = list.getJSONObject(j);
                                    Log.d(TAG, CLASS_NAME + "    ---- current resourceID=" + obj.getString("resourceID"));
                                    Log.d(TAG, CLASS_NAME + "    ---- current resourceVersion=" + obj.getString("resourceVersion"));
                                    if (resourceID.equals(obj.getString("resourceID"))) {
                                        if (!resourceVersion.equals(obj.getString("resourceVersion"))) {
                                            EOMUpdateInfo info = new EOMUpdateInfo();
                                            info.url = resourceUrl;
                                            info.version = resourceVersion;
                                            info.id = resourceID;
                                            info.md5 = md5;
                                            Log.d(TAG, CLASS_NAME + "onReplySvrHttp url=" + info.url + " ver=" + info.version
                                                + " id=" + info.id + " md5=" + info.md5);
                                            mDownloadList.add(info);
                                        }
                                    }
                                }
                                Log.d(TAG, CLASS_NAME + "======================================================================");
                            }

                            Log.d(TAG, CLASS_NAME + "onReplySvrHttp need update size=" + mDownloadList.size());
                            if (mDownloadList.size() > 0) {
                                setTablistUpdateStatus();
                                setUpdataState(EOMDataInfoDef.UPDATE_STATUS.WAITUPDATE);

                                // notify messagecenter
                                MessageServiceManager msg =  MessageServiceManager.getInstance();
                                if (null != msg) {
                                    String omContentTitle = repJSONObject.getString("omContentTitle");
                                    String omContentText = repJSONObject.getString("omContentText");
                                    CarNotification notification = new CarNotification(omContentTitle, omContentText, 685, CarNotification.DISPLAY_POS_LEFT, CarNotification.CATEGORY_EOM);
                                    msg.sendNotification(notification);
                                }
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }
        }

        @Override
        public void notifyHttpCommonHeaderReadyStatus(boolean status) {
            Log.d(TAG, CLASS_NAME + "MyGBookListener notifyHttpCommonHeaderReadyStatus status=" + status);
            initGBookData();
        }

        @Override
        public void onHttpProgressCallback(TSConnectHttpProgress rep) {
            Log.d(TAG, CLASS_NAME + "MyGBookListener onHttpProgressCallback id=" + rep.getConnectId() +
                " reqid=" + rep.getReqId() + " downloadtotal=" + rep.getDownloadTotal() + " downloadnow=" + rep.getDownloadNow());
            if (rep.getDownloadTotal() == rep.getDownloadNow()) {
                if (mUpdateMap.isEmpty()) {
                    Log.i(TAG, CLASS_NAME + "onHttpProgressCallback mUpdateMap is null");
                    return;
                }
                if (!mUpdateMap.containsKey(rep.getReqId())) {
                    Log.i(TAG, CLASS_NAME + "onHttpProgressCallback mUpdateMap is not containsKey");
                    return;
                }
                String id = mUpdateMap.get(rep.getReqId());
                updateDownloadFinish(id);
            }
        }
    }

    @Override
    public ArrayList<TabCategoryItem> getTabCategoryList() {
        if (null != mTabList) {
            Log.i(TAG, CLASS_NAME + "getTabCategoryList size=" + mTabList.size());
            return mTabList;
        }
        else {
            Log.d(TAG, CLASS_NAME + "getTabCategoryList list is null.");
            return null;
        }
    }

    @Override
    public ArrayList<VideoItem> getVideoList() {
        if (null != mVideoList) {
            Log.i(TAG, CLASS_NAME + "getVideoList size=" + mVideoList.size());
            return mVideoList;
        }
        else {
            Log.d(TAG, CLASS_NAME + "getVideoList list is null.");
            return null;
        }
    }

    @Override
    public ArrayList<SearchHistoryItem> getSearchHistoryList() {
        return null;
    }

    @Override
    public ArrayList<SearchResultItem> getSearchResultList() {
        return null;
    }

    @Override
    public int getUpdateState() {
        Log.i(TAG, CLASS_NAME + "getUpdateState mUpdateState=" + mUpdateState);
        return mUpdateState;
    }

    @Override
    public void reqOpenPop(String funcid, int useType) {

        Log.i(TAG, CLASS_NAME + "reqOpenPop begin funcid=" + funcid + " useType=" + useType);
        if (mSecondFuncUrlList.isEmpty()) {
            Log.i(TAG, CLASS_NAME + "reqOpenPop mSecondFuncUrlList is null");
            return;
        }
        if (!mSecondFuncUrlList.containsKey(funcid)) {
            Log.i(TAG, CLASS_NAME + "reqOpenPop mSecondFuncUrlList is not containsKey");
            return;
        }
        String url = mSecondFuncUrlList.get(funcid);
        String title = mSecondFuncTitleList.get(funcid);
        Log.i(TAG, CLASS_NAME + "reqOpenPop url=" + url);
        if (url.isEmpty()) {
            Log.i(TAG, CLASS_NAME + "reqOpenPop not find url");
            return;
        }
        mLockListener.readLock().lock();
        for (IEOMListener listener : mListenerMap.values()) {
            try {
                listener.onNotifyOpenPop(url, title);
            } catch (Exception e) {
                Log.e(TAG, Log.getStackTraceString(e));
            }
        }
        mLockListener.readLock().unlock();


        Log.i(TAG, CLASS_NAME + "reqOpenPop end");
    }

    @Override
    public void reqUpdateAll() {
        Log.i(TAG, CLASS_NAME + "reqUpdateAll begin");
        if (null == mDownloadList) {
            Log.i(TAG, CLASS_NAME + "reqUpdateAll mDownloadList is null");
            return;
        }
        if (null == mGBookManager) {
            Log.i(TAG, CLASS_NAME + "reqUpdateAll mGBookManager is null");
            return;
        }
        if (!mGBookManager.getHttpCommonHeaderReadyStatus()) {
            Log.i(TAG, CLASS_NAME + "reqUpdateAll getHttpCommonHeaderReadyStatus not ready");
            return;
        }
        if (null != mGBookManager) {
            if (!mGBookManager.getHttpCommonHeaderReadyStatus()) {
                Log.i(TAG, CLASS_NAME + "reqUpdateAll getHttpCommonHeaderReadyStatus not ready");
                return;
            }
            setUpdataState(EOMDataInfoDef.UPDATE_STATUS.UPDATING);
            Log.i(TAG, CLASS_NAME + "reqUpdateAll size=" + mDownloadList.size());
            for (int i = 0; i < mDownloadList.size(); i++) {

                TSConnectHttpRequestIn req = new TSConnectHttpRequestIn();

                req.setConnectId("com.iauto.electronicom");
                Integer reqid = mReqId++;
                req.setReqId(reqid);
                req.setReqType(IGBookDef.ReqType.TSCONNECT_REQ_TYPE_RESOURCE);
                req.setReqMethod(IGBookDef.ReqMethod.TSCONNECT_REQ_METHOD_GET);
                String downloadurl = downloadUrl + mDownloadList.get(i).url;
                Log.i(TAG, CLASS_NAME + "reqUpdateAll downloadurl=" + mDownloadList.get(i).url);
                req.setUrl(mDownloadList.get(i).url);
                String requestId = java.util.UUID.randomUUID().toString();
                req.addHttpHeaders("requestId", requestId);
                req.addHttpHeaders("Content-Type", "application/octet-stream");
                req.setPosDataType(IGBookDef.PosDataType.TSCONNECT_POSDATA_NODATA);
                req.setResDataType(IGBookDef.ResDataType.TSCONNECT_RESDATA_FILE);
                req.setIsProgressCallback(true);
                String downloadfile = DOWNLOAD_PATH + mDownloadList.get(i).id + ".dat";
                Log.i(TAG, CLASS_NAME + "reqUpdateAll downloadfile=" + downloadfile);
                req.setResFileName(downloadfile);

                mUpdateMap.put(reqid, mDownloadList.get(i).id);

                mGBookManager.requestSvrHttp(req);
            }
        }
        Log.i(TAG, CLASS_NAME + "reqUpdateAll end");
    }

    @Override
    public void reqSearching(String keywords) {
        Log.i(TAG, CLASS_NAME + "reqSearching keywords=" + keywords);
        query(keywords);
    }

    @Override
    public void reqClearSearchHistory() {

    }

    public ArrayList<SearchResultItem> query(String keywords) {
        Log.i(TAG, CLASS_NAME + "query keywords=" + keywords);
        ArrayList<SearchResultItem> searchList = new ArrayList<>();
        if (null != mEOMSearch) {
            searchList = mEOMSearch.query(keywords);
        }
        Log.i(TAG, CLASS_NAME + "query list size=" + searchList.size());

        mLockListener.readLock().lock();
        for (IEOMListener listener : mListenerMap.values()) {
            try {
                listener.onNotifySearchResultListChange(searchList);
            } catch (Exception e) {
                Log.e(TAG, Log.getStackTraceString(e));
            }
        }
        mLockListener.readLock().unlock();

        return searchList;
    }

    private void parseConfigJson() {
        Log.i(TAG, CLASS_NAME + "parseConfigJson begin");
        try {
            String config = CONFIG_FILE;
            Log.i(TAG, CLASS_NAME + "parseConfigJson config=" + config);
            JSONObject jsonObject = readJsonFile(config);
            if (null == jsonObject) {
                Log.i(TAG, CLASS_NAME + "parseConfigJson jsonObject is null, return");
                return;
            }

            // get version list for check update
            CarDataValue dataValue = new CarDataValue();
            CarData carData = getCarData();
            int ret = carData.getValue("DM_BK_3DCARMODEL_CURRENT_VERSION", dataValue);
            Log.i(TAG, CLASS_NAME + "get 3d version from cardata, ret=" + ret);
            if (CarData.CAR_DATA_ERROR_OK == ret) {
                Log.i(TAG, CLASS_NAME + "get 3d version=" + dataValue.getString());
                if (dataValue.getString().equals("")) {
                    mVersionJsonObject.put("3DmodelVersion", "V0000");
                }
                else {
                    mVersionJsonObject.put("3DmodelVersion", dataValue.getString());
                }
            }
            else {
                mVersionJsonObject.put("3DmodelVersion", "V0000");
            }
            JSONArray versionJsonArray = new JSONArray();

            JSONArray tabArrary = jsonObject.getJSONArray("tab_list");

            mSecondFuncUrlList.clear();
            mSecondFuncTitleList.clear();

            // init tab list
            ArrayList<TabCategoryItem> tabList = new ArrayList<>();
            Log.i(TAG, CLASS_NAME + "parseConfigJson tabArrary length=" + tabArrary.length());
            for (int i = 0; i < tabArrary.length(); i++) {
                JSONObject tabObj = tabArrary.getJSONObject(i);
                TabCategoryItem tabItem = new TabCategoryItem();
                if (isLanguageZh()) {
                    tabItem.setName(tabObj.getString("title_cn"));
                }
                else {
                    tabItem.setName(tabObj.getString("title_eng"));
                }

                if (tabObj.getString("type").equals("1")) {
                   Log.i(TAG, CLASS_NAME + "parseConfigJson continue i=" + i);
                    continue;
                }
                ArrayList<FuncListItem> funcList = new ArrayList<FuncListItem>();
                JSONArray firstFuncArray = tabObj.getJSONArray("list");
                Log.i(TAG, CLASS_NAME + "parseConfigJson firstFuncArray length=" + firstFuncArray.length());
                for (int j = 0; j < firstFuncArray.length(); j++) {
                    JSONObject firstFuncObj = firstFuncArray.getJSONObject(j);

                    FuncListItem item = new FuncListItem();
                    String language = "cn";
                    if (isLanguageZh()) {
                        item.setName(firstFuncObj.getString("title_cn"));
                        language = "cn";
                    }
                    else {
                        item.setName(firstFuncObj.getString("title_eng"));
                        language = "eng";
                    }

                    item.setId(firstFuncObj.getString("resource_id"));

                    // get version list for check update
                    JSONObject object= new JSONObject();
                    object.put("resourceVersion", firstFuncObj.getString("resource_version"));
                    object.put("resourceID", firstFuncObj.getString("resource_id"));
                    versionJsonArray.put(object);

                    ArrayList<SecondFuncListItem> secondFuncList = new ArrayList<SecondFuncListItem>();
                    JSONArray secondFuncArray = firstFuncObj.getJSONArray("list");
                    for (int k = 0; k < secondFuncArray.length(); k++) {
                        JSONObject secondFuncObj = secondFuncArray.getJSONObject(k);

                        SecondFuncListItem secondItem = new SecondFuncListItem();
                        String secondFuncId = secondFuncObj.getString("func_id");
                        if (isLanguageZh()) {
                            secondItem.setName(secondFuncObj.getString("title_cn"));
                            mSecondFuncTitleList.put(secondFuncId, secondFuncObj.getString("title_cn"));
                        }
                        else {
                            secondItem.setName(secondFuncObj.getString("title_eng"));
                            mSecondFuncTitleList.put(secondFuncId, secondFuncObj.getString("title_eng"));
                        }
                        String itemPath = String.format(RESOURCE_H5_PATH, firstFuncObj.getString("url"), language, secondFuncObj.getString("h5"));
                        secondItem.setId(secondFuncId);
                        secondItem.setPath(itemPath);
                        secondFuncList.add(secondItem);
                        mSecondFuncUrlList.put(secondFuncId, itemPath);
                    }
                    item.setSecondFuncList(secondFuncList);

                    funcList.add(item);
                }
                tabItem.setFuncList(funcList);

                tabList.add(tabItem);
            }
            mTabList.clear();
            mTabList.addAll(tabList);
            Log.i(TAG, CLASS_NAME + "===mTabList length=" + mTabList.size());

            // init video list
            JSONObject videoTabObject = tabArrary.getJSONObject(0);
            JSONArray videoArrary = videoTabObject.getJSONArray("list_video");
            Log.i(TAG, CLASS_NAME + "parseConfigJson videoArrary length=" + videoArrary.length());

            mVideoList.clear();
            for (int i = 0; i < videoArrary.length(); i++) {
                JSONObject obj = videoArrary.getJSONObject(i);
                VideoItem item = new VideoItem();
                String language = "cn";
                if (isLanguageZh()) {
                    item.setName(obj.getString("title_cn"));
                    language = "cn";
                }
                else {
                    item.setName(obj.getString("title_eng"));
                    language = "eng";
                }
                String videoPath = String.format(RESOURCE_VIDEO_PATH, obj.getString("url"), language, obj.getString("video"));
                String picPath = String.format(RESOURCE_VIDEO_PATH, obj.getString("url"), language, obj.getString("pic"));
                Log.i(TAG, CLASS_NAME + "parseConfigJson videoPath=" + videoPath + " picPath=" + picPath);
                item.setPath(videoPath);

                try {
                    File file = new File(picPath);
                    FileInputStream pic = new FileInputStream(file);
                    Bitmap bitmap = BitmapFactory.decodeStream(pic);
                    item.setArtwork(bitmap);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                item.setId(obj.getString("func_id"));
                mVideoList.add(item);
            }
            // getEOMModel().setVideoList(mVideoList);

            mVersionJsonObject.put("omResourceList", versionJsonArray);

        } catch (JSONException e) {
            Log.i(TAG, CLASS_NAME + "parseConfigJson JSONException");
            e.printStackTrace();
        }
        Log.i(TAG, CLASS_NAME + "parseConfigJson end");
    }

    private VideoItem getVideoItemByFuncId(String funcid) {
        VideoItem video = new VideoItem();
        for (int i = 0; i < mVideoList.size(); i++) {
            if (null != mVideoList.get(i) && funcid.equals(mVideoList.get(i).getId())) {
                video = mVideoList.get(i);
                break;
            }
        }
        return video;
    }

    private boolean isLanguageZh() {
        String language = Locale.getDefault().getLanguage();
        if (language.equals("zh")) {
            return true;
        }
        return false;
    }

    private JSONObject readJsonFile(String filename) {
        Log.i(TAG, CLASS_NAME + "readJsonFile begin filename=" + filename);
        String jsonString = "";
        try {
            Reader reader = new InputStreamReader(new FileInputStream(filename), "utf-8");
            int ch = 0;
            StringBuffer stringBuffer = new StringBuffer();

            while ((ch = reader.read()) != -1) {
                stringBuffer.append((char) ch);
            }

            reader.close();
            jsonString = stringBuffer.toString();

        } catch (Exception e) {
            Log.e(TAG, CLASS_NAME + "readJsonFile exception1:" + e);
            e.printStackTrace();
        }
        try {
            JSONObject obj = new JSONObject(jsonString);
            Log.i(TAG, CLASS_NAME + "readJsonFile end");
            return obj;
        } catch (JSONException e) {
            Log.e(TAG, CLASS_NAME + "readJsonFile exception2:" + e);
            e.printStackTrace();
        }

        Log.i(TAG, CLASS_NAME + "readJsonFile end return null");

        return null;
    }

    private void setUpdataState(int state) {
        Log.i(TAG, CLASS_NAME + "setUpdataState state=" + state);
        if (mUpdateState != state) {
            mUpdateState = state;
            mLockListener.readLock().lock();
            for (IEOMListener listener : mListenerMap.values()) {
                try {
                    listener.onNotifyUpdateState(state);
                } catch (Exception e) {
                    Log.e(TAG, Log.getStackTraceString(e));
                }
            }
            mLockListener.readLock().unlock();
        }

    }

}

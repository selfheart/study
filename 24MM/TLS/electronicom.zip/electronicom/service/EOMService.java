package com.iauto.electronicom.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class EOMService extends Service {
    private static final String TAG = "EOM-SERVICE";

    private EOMServiceImpl mServiceImpl;

    public EOMService() {
    }

    @Override
    public void onCreate() {
        Log.i(TAG, "onCreate begin");
        mServiceImpl = EOMServiceImpl.getInstance(this);
        mServiceImpl.init();
        Log.i(TAG, "onCreate end");
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.i(TAG, "onBind");
        return mServiceImpl;
    }

    @Override
    public void onDestroy() {
        Log.i(TAG, "onDestroy begin");
        if (mServiceImpl != null) {
            mServiceImpl.releaseInstance();
        }
        super.onDestroy();
        Log.i(TAG, "onDestroy end");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "onStartCommand begin");
        return START_STICKY;
    }
}
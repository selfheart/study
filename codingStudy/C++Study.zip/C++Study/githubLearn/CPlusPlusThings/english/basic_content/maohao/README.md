# :: Story about range resolution operators

## Abput Author：


![](../img/wechat.jpg)

- Global scope（::name）：Used before a type name (class, class member, member function, variable, etc.), indicates that the scope is a global namespace
- Class scope（class::name）：The scope used to represent the specified type is class specific
- Namespace scope（namespace::name）: The scope used to represent the specified type is a namespace specific

Code ：[maohao.cpp](maohao.cpp)


class Apple
{
private:
    int people[100];
public:
    Apple(int i);
    static const int apple_number;
    void take(int num) const;
    int add(int num);
    int add(int num) const;
    int getCount() const;
};


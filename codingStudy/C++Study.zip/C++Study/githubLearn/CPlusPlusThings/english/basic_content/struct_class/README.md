# The difference struct and class



![](../img/wechat.jpg)

More detail about struct [Story about struct](../struct)

Generally speaking, struct is more suitable to be regarded as an implementation body of data structure, and class is more suitable to be regarded as the implementation body of an object. 

Dif:

One of the essential differences is the default access control



Default inherited access.Struct is public, while class is private.

Structure as the implementation body of data structure.Its default data access control is public, while class is the implementation body of the object, and its default member variable access control is private.

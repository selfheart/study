#ifndef ADD_H
#define ADD_H
extern int add(int x,int y);
#endif

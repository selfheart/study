/* 注释.cpp */
#include <iostream>

//另一种注释方法
#if 0
asd
#endif

//打开注释
//条件编译指令
#if 1
#endif

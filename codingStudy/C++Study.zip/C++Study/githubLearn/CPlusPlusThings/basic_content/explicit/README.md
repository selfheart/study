# explicit(显式)关键字那些事

## 关于作者：

个人公众号：

![](../img/wechat.jpg)

- explicit 修饰构造函数时，可以防止隐式转换和复制初始化
- explicit 修饰转换函数时，可以防止隐式转换，但按语境转换除外


代码参见:[.explicit.cpp](./explicit.cpp)

参考链接：
> https://stackoverflow.com/questions/4600295/what-is-the-meaning-of-operator-bool-const

#ifndef ADD_H
#define ADD_H
extern "C" {
int add(int x, int y);
}
#endif

extern int add(int x,int y);
int main() {
    add(2,3);
    return 0;
}
